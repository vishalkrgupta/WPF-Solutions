﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikEditorControls
{
    /// <summary>
    /// Interaction logic for ColorEditorDemo.xaml
    /// </summary>
    public partial class ColorEditorDemo : Window
    {
        public ColorEditorDemo()
        {
            InitializeComponent();
        }

        private void RadColorEditor_SelectedColorChanged(object sender, Telerik.Windows.Controls.ColorEditor.ColorChangeEventArgs e)
        {
            MessageBox.Show(String.Format("You selected {0}", e.Color.ToString()));
        }

        private void RadColorPicker_SelectedColorChanged(object sender, EventArgs e)
        {
            MessageBox.Show(String.Format("You selected {0}", colorPicker.SelectedColor ));
        }
    }
}
