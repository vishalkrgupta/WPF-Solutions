﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikDataNavigationControls
{
    /// <summary>
    /// Interaction logic for TransitionDemo.xaml
    /// </summary>
    public partial class TransitionDemo : Window
    {
        public TransitionDemo()
        {
            InitializeComponent();
            this.Loaded += TransitionDemo_Loaded;
        }

        void TransitionDemo_Loaded(object sender, RoutedEventArgs e)
        {
            lbx.ItemsSource = FlowerService.Flowers;
            lbx.DisplayMemberPath = "Name";
        }
    }

    public class Flower
    {
        public string Name { get; set; }
        public string ImageUrl { get; set; }
    }

    public class FlowerService
    {
        public static ObservableCollection<Flower> Flowers
        {
            get
            {
                return new ObservableCollection<Flower> { 
                new Flower{ Name="Chrysanthemum", ImageUrl ="Chrysanthemum.jpg" },
                new Flower{ Name="Hydrangeas", ImageUrl ="Hydrangeas.jpg" },
                new Flower{ Name="Tulips", ImageUrl ="Tulips.jpg" }};
            }
        }
    }
}
