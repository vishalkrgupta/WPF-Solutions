﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikLayoutControls
{
    /// <summary>
    /// Interaction logic for D02_CarouselDemo.xaml
    /// </summary>
    public partial class D02_CarouselDemo : Window
    {
        public D02_CarouselDemo()
        {
            InitializeComponent();
            this.Loaded += D02_CarouselDemo_Loaded;
        }

        void D02_CarouselDemo_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                var employees = (from emp in db.Employees
                                 select new 
                                 {
                                     FirstName = emp.FirstName,
                                     LastName = emp.LastName
                                 }).ToList();

                car.ItemsSource = employees;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception due to {0}", ex.Message);
            }
        }
    }
}
