﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelerikDataEntryOperatorsDemo
{
    /// <summary>
    /// Interaction logic for ComboBoxDemo.xaml
    /// </summary>
    public partial class ComboBoxDemo : Window
    {
        public ComboBoxDemo()
        {
            InitializeComponent();
        }
    }

    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
    }

    public class PersonViewModel
    {
        public ObservableCollection<Person> People
        {
            get
            {
                return new ObservableCollection<Person> { 
                    new Person{ FirstName = "John"  , LastName="Lee", City="Delhi"},
                    new Person{ FirstName = "Tom"   , LastName="XYZ", City="Pune"},
                    new Person{ FirstName = "Joe"   , LastName="Hardy", City="Goa"},
                    new Person{ FirstName = "Joseph", LastName="Lobo", City="Agra"},
                    new Person{ FirstName = "Josef" , LastName="Chan", City="Kochi"},
                    new Person{ FirstName = "Jojo"  , LastName="Chen", City="Chennai"},
                    new Person{ FirstName = "Jackie", LastName="Li", City="Mumbai"},
                    new Person{ FirstName = "Jack"  , LastName="Wu", City="Pune"}
                    };
            }
        }
    }
}
